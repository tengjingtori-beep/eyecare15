// EyeCare15 — 医学的根拠にもとづく「目にやさしい」tweak
// iPhone 7 / iOS 15 / Dopamine (rootless) / SpringBoard 専用
//
//
// ・デジタル眼精疲労の主因はブルーライトそのものではない。
// 米国眼科学会(AAO): 画面のブルーライトが目を傷める科学的証拠はない。
// Cochraneレビュー(2023, 無作為化試験17件/619人): ブルーライトカット
// レンズは眼精疲労を減らすとは言えない。
// ・本当の主因は (1)まばたき減少 (通常 約15回/分 → 画面注視時 5〜7回/分)
// による乾燥、(2)近距離でピント調節(毛様体筋)を続ける疲れ、
// (3)画面と部屋の明るさの差・まぶしさ、(4)休みなしの連続使用。
// ・効くとされる対策: 20-20-20ルール (20分ごとに20秒、約6m先を見る)、
// 意識的なまばたき、明るさと周囲を合わせる、長時間連続を避ける
// (厚労省 情報機器作業ガイドライン: 連続1時間を超えず10〜15分休止)、
// 夜は画面を暗くして就寝前の刺激を減らす (睡眠衛生)。
//
// 上記の「効く側」だけを実装する。
// 1. 20-20-20休憩リマインダー (既定20分ごと、20秒の休憩画面+まばたき案内)
// スキップし続けると「長めの休憩」版 (60秒) になる。
// 2. 夜のウォーム＆減光フィルター (既定19時〜7時は自動、強さ調整可)
// ※色を変える重ね表示による再現。眼精疲労対策ではなく
// 「夜に画面を暗く・まぶしくなくする」ためのものとして実装。
// 3. ロック中は休憩画面を出さない (SBSGetScreenLockStatus で判定)。
//
// 自分の設定ファイル (app.hane.eyecare15) を読むだけ。
// ユーザーのデータには触らない・消さない。アンインストール+リスプリングで
// 完全に元の状態に戻る。

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <dlfcn.h>

static NSString * const kPrefsID = @"app.hane.eyecare15";
static NSString * const kPrefsChanged = @"app.hane.eyecare15.changed";

// ---------- 設定 ----------
static BOOL prefEnabled = YES;
static BOOL prefBreakEnabled = YES;
static double prefBreakIntervalMin = 20.0; // 分
static BOOL prefWarmEnabled = YES;
static BOOL prefWarmAuto = YES; // 19時〜7時のみ
static double prefWarmIntensity = 0.18; // 0.05〜0.40

static id ECAppValue(NSString *key) {
return (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)key,
(__bridge CFStringRef)kPrefsID);
}

static void loadPrefs(void) {
id v;
v = ECAppValue(@"Enabled"); if (v) prefEnabled = [v boolValue];
v = ECAppValue(@"BreakEnabled"); if (v) prefBreakEnabled = [v boolValue];
v = ECAppValue(@"BreakInterval"); if (v) prefBreakIntervalMin = MIN(60.0, MAX(10.0, [v doubleValue]));
v = ECAppValue(@"WarmEnabled"); if (v) prefWarmEnabled = [v boolValue];
v = ECAppValue(@"WarmAuto"); if (v) prefWarmAuto = [v boolValue];
v = ECAppValue(@"WarmIntensity"); if (v) prefWarmIntensity = MIN(0.40, MAX(0.0, [v doubleValue]));
CFPreferencesAppSynchronize((__bridge CFStringRef)kPrefsID);
}

// ---------- タッチを通すフィルター用ウィンドウ ----------
@interface ECFilterWindow: UIWindow
@end
@implementation ECFilterWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event { return nil;}
@end

// ---------- マネージャ ----------
@interface ECManager: NSObject
@property (nonatomic, strong) ECFilterWindow *filterWindow;
@property (nonatomic, strong) UIView *warmView;
@property (nonatomic, strong) UIView *dimView;
@property (nonatomic, strong) UIWindow *breakWindow;
@property (nonatomic, strong) UILabel *breakTitle;
@property (nonatomic, strong) UILabel *breakBody;
@property (nonatomic, strong) UILabel *breakCount;
@property (nonatomic, strong) NSTimer *scheduleTimer;
@property (nonatomic, strong) NSTimer *breakTimer;
@property (nonatomic, strong) NSTimer *countTimer;
@property (nonatomic) NSInteger countLeft;
@property (nonatomic, strong) NSDate *lastCompletedBreak;
@property (nonatomic) BOOL setupDone;
+ (instancetype)shared;
- (void)setup;
- (void)applyPrefs;
- (BOOL)deviceLocked;
@end

@implementation ECManager

+ (instancetype)shared {
static ECManager *s; static dispatch_once_t once;
dispatch_once(&once, ^{ s = [[ECManager alloc] init];});
return s;
}

- (UIWindowScene *)activeScene {
for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
if ([s isKindOfClass:UIWindowScene.class]) return (UIWindowScene *)s;
}
return nil;
}

- (BOOL)deviceLocked {
static void *handle = NULL;
typedef mach_port_t (*PortFn)(void);
typedef void (*LockFn)(mach_port_t, BOOL *, BOOL *);
static PortFn portFn = NULL;
static LockFn lockFn = NULL;
if (!lockFn) {
handle = dlopen("/System/Library/PrivateFrameworks/SpringBoardServices.framework/SpringBoardServices", RTLD_LAZY);
if (!handle) return NO;
portFn = (PortFn)dlsym(handle, "SBSSpringBoardServerPort");
lockFn = (LockFn)dlsym(handle, "SBSGetScreenLockStatus");
if (!lockFn) return NO;
}
BOOL locked = NO, passcode = NO;
lockFn(portFn? portFn(): 0, &passcode, &locked);
return locked;
}

- (void)setup {
if (self.setupDone) return;
self.setupDone = YES;
self.lastCompletedBreak = [NSDate date];
UIWindowScene *scene = [self activeScene];
CGRect bounds = scene? scene.coordinateSpace.bounds: UIScreen.mainScreen.bounds;

// --- フィルター (常時・タッチ透過) ---
self.filterWindow = [[ECFilterWindow alloc] initWithFrame:bounds];
if (scene) self.filterWindow.windowScene = scene;
self.filterWindow.windowLevel = UIWindowLevelStatusBar + 50;
self.filterWindow.backgroundColor = UIColor.clearColor;
UIViewController *fvc = [[UIViewController alloc] init];
fvc.view.backgroundColor = UIColor.clearColor;
fvc.view.userInteractionEnabled = NO;
self.dimView = [[UIView alloc] initWithFrame:bounds];
self.dimView.backgroundColor = UIColor.blackColor;
self.dimView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
self.warmView = [[UIView alloc] initWithFrame:bounds];
self.warmView.backgroundColor = [UIColor colorWithRed:1.0 green:0.62 blue:0.18 alpha:1.0];
self.warmView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
[fvc.view addSubview:self.dimView];
[fvc.view addSubview:self.warmView];
self.filterWindow.rootViewController = fvc;
self.filterWindow.hidden = NO;

// --- 休憩画面 (必要なときだけ) ---
self.breakWindow = [[UIWindow alloc] initWithFrame:bounds];
if (scene) self.breakWindow.windowScene = scene;
self.breakWindow.windowLevel = UIWindowLevelAlert + 10;
self.breakWindow.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.62];
UIViewController *bvc = [[UIViewController alloc] init];
bvc.view.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.62];

UIView *card = [[UIView alloc] init];
card.backgroundColor = [UIColor colorWithWhite:0.10 alpha:0.96];
card.layer.cornerRadius = 20;
card.translatesAutoresizingMaskIntoConstraints = NO;
[bvc.view addSubview:card];

self.breakTitle = [[UILabel alloc] init];
self.breakTitle.text = @"目の休憩タイム";
self.breakTitle.font = [UIFont boldSystemFontOfSize:22];
self.breakTitle.textColor = UIColor.whiteColor;
self.breakTitle.textAlignment = NSTextAlignmentCenter;
self.breakTitle.translatesAutoresizingMaskIntoConstraints = NO;
[card addSubview:self.breakTitle];

self.breakCount = [[UILabel alloc] init];
self.breakCount.text = @"20";
self.breakCount.font = [UIFont systemFontOfSize:56 weight:UIFontWeightBold];
self.breakCount.textColor = [UIColor colorWithRed:1.0 green:0.80 blue:0.45 alpha:1.0];
self.breakCount.textAlignment = NSTextAlignmentCenter;
self.breakCount.translatesAutoresizingMaskIntoConstraints = NO;
[card addSubview:self.breakCount];

self.breakBody = [[UILabel alloc] init];
self.breakBody.text = @"画面から目を離して、6m先の遠くを見ましょう。\nゆっくり まばたきも 5回。\nスマホは 40cm 以上 離して持つのがおすすめです。";
self.breakBody.font = [UIFont systemFontOfSize:15];
self.breakBody.textColor = [UIColor colorWithWhite:0.92 alpha:1.0];
self.breakBody.textAlignment = NSTextAlignmentCenter;
self.breakBody.numberOfLines = 0;
self.breakBody.translatesAutoresizingMaskIntoConstraints = NO;
[card addSubview:self.breakBody];

UIButton *skip = [UIButton buttonWithType:UIButtonTypeSystem];
[skip setTitle:@"今はスキップ" forState:UIControlStateNormal];
[skip setTitleColor:[UIColor colorWithWhite:0.75 alpha:1.0] forState:UIControlStateNormal];
skip.titleLabel.font = [UIFont systemFontOfSize:15];
skip.translatesAutoresizingMaskIntoConstraints = NO;
[skip addTarget:self action:@selector(onSkip) forControlEvents:UIControlEventTouchUpInside];
[card addSubview:skip];

[NSLayoutConstraint activateConstraints:@[
[card.centerXAnchor constraintEqualToAnchor:bvc.view.centerXAnchor],
[card.centerYAnchor constraintEqualToAnchor:bvc.view.centerYAnchor],
[card.widthAnchor constraintLessThanOrEqualToConstant:320],
[card.leadingAnchor constraintGreaterThanOrEqualToAnchor:bvc.view.leadingAnchor constant:24],
[card.trailingAnchor constraintLessThanOrEqualToAnchor:bvc.view.trailingAnchor constant:-24],
[self.breakTitle.topAnchor constraintEqualToAnchor:card.topAnchor constant:22],
[self.breakTitle.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16],
[self.breakTitle.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-16],
[self.breakCount.topAnchor constraintEqualToAnchor:self.breakTitle.bottomAnchor constant:8],
[self.breakCount.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16],
[self.breakCount.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-16],
[self.breakBody.topAnchor constraintEqualToAnchor:self.breakCount.bottomAnchor constant:8],
[self.breakBody.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:18],
[self.breakBody.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-18],
[skip.topAnchor constraintEqualToAnchor:self.breakBody.bottomAnchor constant:14],
[skip.centerXAnchor constraintEqualToAnchor:card.centerXAnchor],
[skip.bottomAnchor constraintEqualToAnchor:card.bottomAnchor constant:-16],
]];
self.breakWindow.rootViewController = bvc;
self.breakWindow.hidden = YES;

// 30秒ごとに夜間スケジュールを確認
self.scheduleTimer = [NSTimer scheduledTimerWithTimeInterval:30 repeats:YES
block:^(NSTimer *t) { [[ECManager shared] applyPrefs];}];
[self applyPrefs];
[self restartBreakTimer];
}

- (BOOL)warmActiveNow {
if (!prefEnabled ||!prefWarmEnabled) return NO;
if (!prefWarmAuto) return YES;
NSInteger hour = [[NSCalendar currentCalendar] component:NSCalendarUnitHour fromDate:[NSDate date]];
return (hour >= 19 || hour < 7);
}

- (void)applyPrefs {
if (!self.setupDone) return;
BOOL warm = [self warmActiveNow];
self.warmView.alpha = warm? (CGFloat)prefWarmIntensity: 0.0;
self.dimView.alpha = warm? (CGFloat)(prefWarmIntensity * 0.45): 0.0;
self.filterWindow.hidden =!prefEnabled;
if (!prefEnabled ||!prefBreakEnabled) {
[self hideBreakCompleted:NO];
}
}

- (void)restartBreakTimer {
[self.breakTimer invalidate];
self.breakTimer = nil;
if (!prefEnabled ||!prefBreakEnabled) return;
NSTimeInterval interval = prefBreakIntervalMin * 60.0;
self.breakTimer = [NSTimer scheduledTimerWithTimeInterval:interval repeats:NO
block:^(NSTimer *t) { [[ECManager shared] maybeShowBreak];}];
}

- (void)maybeShowBreak {
if (!prefEnabled ||!prefBreakEnabled) { [self restartBreakTimer]; return;}
if ([self deviceLocked]) { // ロック中は出さず、少し後に再試行
[self.breakTimer invalidate];
self.breakTimer = [NSTimer scheduledTimerWithTimeInterval:120 repeats:NO
block:^(NSTimer *t) { [[ECManager shared] maybeShowBreak];}];
return;
}
// 前回の「完了した休憩」から50分以上たっていたら長め版 (厚労省ガイドライン寄せ)
NSTimeInterval since = [[NSDate date] timeIntervalSinceDate:self.lastCompletedBreak?: [NSDate date]];
BOOL longBreak = since >= 50 * 60;
self.countLeft = longBreak? 60: 20;
self.breakTitle.text = longBreak? @"長めの休憩をおすすめ": @"目の休憩タイム";
self.breakBody.text = longBreak
? @"長く画面を見続けました。\n立ち上がって遠くを見ましょう。\nゆっくり まばたきも 5回。"
: @"画面から目を離して、6m先の遠くを見ましょう。\nゆっくり まばたきも 5回。\nスマホは 40cm 以上 離して持つのがおすすめです。";
self.breakCount.text = [NSString stringWithFormat:@"%ld", (long)self.countLeft];
self.breakWindow.hidden = NO;
[self.countTimer invalidate];
self.countTimer = [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES
block:^(NSTimer *t) { [[ECManager shared] tickCount];}];
}

- (void)tickCount {
self.countLeft -= 1;
if (self.countLeft <= 0) { [self hideBreakCompleted:YES]; return;}
self.breakCount.text = [NSString stringWithFormat:@"%ld", (long)self.countLeft];
}

- (void)onSkip { [self hideBreakCompleted:NO];}

- (void)hideBreakCompleted:(BOOL)completed {
[self.countTimer invalidate]; self.countTimer = nil;
self.breakWindow.hidden = YES;
if (completed) self.lastCompletedBreak = [NSDate date];
[self restartBreakTimer];
}

@end

// ---------- 起動 ----------
@interface SpringBoard: UIApplication
@end

%hook SpringBoard
- (void)applicationDidFinishLaunching:(UIApplication *)application {
%orig;
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
dispatch_get_main_queue(), ^{
[[ECManager shared] setup];
});
}
%end

static void prefsChangedCallback(CFNotificationCenterRef center, void *observer,
CFStringRef name, const void *object, CFDictionaryRef userInfo) {
dispatch_async(dispatch_get_main_queue(), ^{
loadPrefs();
ECManager *m = [ECManager shared];
if (m.setupDone) { [m applyPrefs]; [m restartBreakTimer];}
});
}

%ctor {
@autoreleasepool {
loadPrefs();
CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
prefsChangedCallback, (__bridge CFStringRef)kPrefsChanged, NULL,
CFNotificationSuspensionBehaviorDeliverImmediately);
%init;
}
}
